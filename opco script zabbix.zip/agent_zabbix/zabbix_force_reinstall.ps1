﻿
$services = Get-Service -Name "*zabbix*"

$nb_service = Get-Service -Name "*zabbix*" | Measure-Object

if ($nb_service.Count -gt 0)

{

    foreach ($service in $services)
    {
        $service.Name | Stop-Service -Force -PassThru
        sc.exe delete $service.Name
        reg delete "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\EventLog\Application\Zabbix Agent 2" /va /f
        reg delete "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\EventLog\Application\Zabbix Agent 2" /f
    }
}

C:\agent_zabbix\bin\zabbix_agent2.exe -config c:\\agent_zabbix\\conf\\zabbix_agent2.conf -install
C:\agent_zabbix\bin\zabbix_agent2.exe -config c:\\agent_zabbix\\conf\\zabbix_agent2.conf -start